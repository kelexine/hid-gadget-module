# Changelog Archive

<!-- Archived on 2025-08-12 21:05 -->


## v1.23.1 (2025-08-12 21:05)

- Version code: 12301
- Changes since v1.23.0:
  - Summary:  8 files changed, 31 insertions(+), 9 deletions(-)

### Commits
- ee29cef Automated build: v1.23.1 (kelexine)
- 44ad7e2 Automated build: v1.23.1 (kelexine)
- 100afe8 Automated build: v1.23.1 (kelexine)
### Files changed
M	CHANGELOG.md
M	blobs/arm/hid-gadget
M	blobs/arm64/hid-gadget
M	blobs/x86/hid-gadget
M	blobs/x86_64/hid-gadget
M	hid-gadget.c
M	module.prop
M	update.json


## v1.23.0 (2025-08-12 20:36)

- Automated build: v1.23.0 (code: 12300)

## v1.22.0 (2025-08-12 20:29)

- Automated build: v1.22.0 (code: 12200)

## v1.21.0 (2025-08-12 20:18)

- Automated build: v1.21.0 (code: 12100)

## v1.20.0 (2025-08-12 20:15)

- Automated build: v1.20.0 (code: 12000)

## v1.19.0 (2025-08-12 20:14)

- Automated build: v1.19.0 (code: 11900)


